import React, { Component } from 'react';

class Page404 extends Component {
  render (){
    return (<div>
      Error404
    </div>);
  };    
}

export default Page404