// Dependencies
import React, { Component } from 'react';

class Footer extends Component {
  render() {
    return (
      <div className="Footer">
        <footer>
          Copyright 2018
        </footer>
      </div>
    );
  }
}

export default Footer;