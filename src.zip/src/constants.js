export const API_URL = "http://localhost/truebase.io/api/v1/";
export const REMOVE_URL = `${API_URL}remove`;
export const CREATE_URL = `${API_URL}create`;
export const RENAME_URL = `${API_URL}rename`;
export const LIST_FOLDER_URL = `${API_URL}listFolder`;